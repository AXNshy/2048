package com.jxm.udpmulticast.JNIDemo;

/**
 * Created by Administrator on 2016/10/11.
 */
public class RequestBody {
    String command;
    String device_num;

    public RequestBody(String command, String device_num) {
        this.command = command;
        this.device_num = device_num;
    }

    public String getCommand() {
        return command;
    }

    public String getDevice_num() {
        return device_num;
    }

    public void setCommand(String command) {

        this.command = command;
    }

    public void setDevice_num(String device_num) {
        this.device_num = device_num;
    }
}
