package com.jxm.udpmulticast.JNIDemo;

import android.content.Context;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * Created by Administrator on 2016/10/11.
 */
public class BroadCastSocket {


    private DatagramSocket sendSocket;
    private DatagramSocket receSocket;



    onUdpCastEvent event;

    private static String Group_Id = "255.255.255.255";
    private static int SocketPort = 3456;
    private static int MAX_BUFFER_SIZE = 256;



    String localIp ;
    public BroadCastSocket() {
        try {

            this.sendSocket = new DatagramSocket(SocketPort);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void receive() throws IOException {

        if(receSocket==null){
            receSocket = new DatagramSocket(SocketPort);
            receSocket.setReuseAddress(true);
            receSocket.setBroadcast(true);
        }
        byte[] receiveData = new byte[MAX_BUFFER_SIZE];

        DatagramPacket rece = new DatagramPacket(receiveData, receiveData.length);

        receSocket.receive(rece);
        String data = new String(rece.getData(), "UTF-8");
//        String packetId = rece.getAddress().toString();
        localIp = rece.getAddress().toString().substring(1);
        if (event != null) {
            event.onReceive(data);
        }

    }

    public int getMyPort(){
        return sendSocket.getPort();
    }

    public void send(DatagramPacket send) {
        try {
            sendSocket.send(send);
            event.onSend(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean isReceivedFromSelf(Context context) {
        if (localIp!=null&&localIp.equals(MainActivity.getLocalPhoneIp(context))) {
            return true;
        }
        return false;
    }

    interface onUdpCastEvent {
        void onReceive(String r);

        void onSend(boolean t);
    }

    public void registerUdpEvent(onUdpCastEvent event) {
        this.event = event;
    }
}
