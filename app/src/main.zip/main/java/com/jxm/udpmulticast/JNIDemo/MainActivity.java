package com.jxm.udpmulticast.JNIDemo;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Message;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.Gson;
import com.jxm.udpmulticast.R;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {


    private static final String TAG = "MainActivity";
    UDPMulticast udpMu;
    BroadCastSocket broad;
    TelephonyManager tm;
    Button sendBtn;
    Button receBtn;
    EditText sendEt;
    TextView receiveTv;
    TextView curIPTv;

    boolean isSendOn = false;
    boolean isReceOn = false;

    Thread sendThread;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            receiveTv.setText((StringBuffer) msg.obj);
            curIPTv.setText("本机IP: " + getLocalPhoneIp(getApplicationContext()));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tm = (TelephonyManager) this.getSystemService(TELEPHONY_SERVICE);
        sendBtn = (Button) findViewById(R.id.btn_send);
        receBtn = (Button) findViewById(R.id.btn_rece);
        receiveTv = (TextView) findViewById(R.id.tv_receive);
        sendEt = (EditText) findViewById(R.id.et_send);
        curIPTv = (TextView) findViewById(R.id.tv_cur_id);
//        initUdpCast();
        initThread();

        receBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isReceOn) {

                    receBtn.setText("RECE ON");
                    isReceOn = true;
                } else {
                    receBtn.setText("RECE OFF");
                    isReceOn = false;

                    return;
                }
            }
        });
        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!isSendOn) {
                    sendBtn.setText("SEND ON");
                    isSendOn = true;
                } else {
                    sendBtn.setText("SEND OFF");
                    isSendOn = false;
                    return;
                }

            }
        });


    }

    private void initThread() {
        new Thread(new Runnable() {//接收UDP
            @Override
            public void run() {
                while (true) {
                    while (isReceOn) {
                        Log.w(TAG, "Receive UDP");
                        try {
                            broad.receive();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        SystemClock.sleep(1000);
                    }
                    SystemClock.sleep(1000);
                }
            }
        }).start();
        new Thread(new Runnable() {//发送UDP
            @Override
            public void run() {
                while (true) {
                    while (isSendOn) {
                        if (!lock.isHeld()) {
                            lock.acquire();
                        }
                        Log.w(TAG, "send UDP");
                        byte[] send = new byte[256];
                        RequestBody re = new RequestBody("boarding", "255.255.255.255");
                        String s = new Gson().toJson(re);
                        send = s.getBytes();
                        int length = send.length;
                        String head = "1000521101" + s;
                        byte[] realsend = head.getBytes();

                        try {
                            InetAddress group = InetAddress.getByName("192.168.16.255");
                            DatagramPacket p = new DatagramPacket(realsend, realsend.length, group, 3456);
                            broad.send(p);
                            SystemClock.sleep(4000);
                        } catch (UnknownHostException e) {
                            e.printStackTrace();
                        }
                    }
                    SystemClock.sleep(1000);
                }
            }
        }).start();
    }

    private void initUdpCast() {

        broad = new BroadCastSocket();
        broad.registerUdpEvent(new BroadCastSocket.onUdpCastEvent() {
            StringBuffer buffer = new StringBuffer();

            @Override
            public void onReceive(String r) {
                if (broad.isReceivedFromSelf(getApplicationContext())) {
                    return;
                }
                buffer.append(r).append("\n");
                Message mes = Message.obtain();
                mes.obj = buffer;
                handler.sendMessage(mes);
                if (lock.isHeld()) {
                    lock.release();
                }
            }

            @Override
            public void onSend(boolean t) {
            }
        });
        WifiManager manager = (WifiManager) this
                .getSystemService(Context.WIFI_SERVICE);
        lock = manager.createMulticastLock("test wifi");
        lock.acquire();
    }

    WifiManager.MulticastLock lock;

    // 获取手机的IP
    public static String getLocalPhoneIp(Context context) {
        if (context == null) {
            return null;
        }

        String ip = null;
        try {
            WifiManager wifiMgr = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = (null == wifiMgr ? null : wifiMgr.getConnectionInfo());
            if (null != info) {
                ip = int2ip(info.getIpAddress());
            }
        } catch (Exception e) {
            // TODO: handle exception
        }
        return ip;
    }

    public static String int2ip(long ipInt) {
        StringBuilder sb = new StringBuilder();
        sb.append(ipInt & 0xFF).append(".");
        sb.append((ipInt >> 8) & 0xFF).append(".");
        sb.append((ipInt >> 16) & 0xFF).append(".");
        sb.append((ipInt >> 24) & 0xFF);
        return sb.toString();
    }
}
