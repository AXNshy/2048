package com.jxm.udpmulticast.JNIDemo;

import android.content.Context;
import android.net.wifi.WifiManager;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

/**
 * Created by Administrator on 2016/10/10.
 */
public class UDPMulticast {
    WifiManager.MulticastLock multicastLock;
    MulticastSocket sendsocket;
    MulticastSocket receSocket;
    DatagramPacket rece,send;

    onUdpCastEvent event;

    private static String Group_Id = "239.255.255.255";
    private static int SocketPort = 3456;

    public UDPMulticast() {
        try {
            this.receSocket = new MulticastSocket(SocketPort);
            this.sendsocket = new MulticastSocket();
            receSocket.setReuseAddress(true);
            receSocket.setBroadcast(true);
            InetAddress group = InetAddress.getByName(Group_Id);
            receSocket.joinGroup(group);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void receive() throws IOException {

        byte[] receiveData = new byte[256];
        if(rece==null){
            rece = new DatagramPacket(receiveData,receiveData.length);
        }
        receSocket.receive(rece);
        String data =new  String(rece.getData(),"UTF-8");
//        String packetId = rece.getAddress().toString();

        if(event!=null){
            event.onReceive(data);
        }

    }

    public void send(DatagramPacket send) {
        try {
            sendsocket.send(send);
            event.onSend(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean isReceivedFromSelf(Context context){
        if(rece.getAddress().toString().equals(MainActivity.getLocalPhoneIp(context))){
            return true;
        }
        return false;
    }

    interface onUdpCastEvent{
        void onReceive(String r);
        void onSend(boolean t);
    }

    public void registerUdpEvent(onUdpCastEvent event){
        this.event=event;
    }
}
