package com.jxm.udpmulticast.JNIDemo;

/**
 * Created by Administrator on 2016/10/11.
 */
public interface Config {
    public static final String Command = "";
}
