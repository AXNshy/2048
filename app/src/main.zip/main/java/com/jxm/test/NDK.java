package com.jxm.test;

/**
 * Created by Administrator on 2016/10/28.
 */

public class NDK {
    public native String getStringFromC();
    public native String getStringFromNative();
}
