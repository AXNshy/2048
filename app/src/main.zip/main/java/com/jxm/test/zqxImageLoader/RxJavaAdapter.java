package com.jxm.test.zqxImageLoader;


import android.graphics.Bitmap;

import rx.Observable;
import rx.Subscriber;

/**
 * Created by Administrator on 2016/10/28.
 */

public class RxJavaAdapter {
    public Observable parseBitmap(String url,int reqWidth,int reqHeight){
        return Observable.create(new Observable.OnSubscribe<Bitmap>() {

            @Override
            public void call(Subscriber<? super Bitmap> subscriber) {

            }
        });
    }
}
